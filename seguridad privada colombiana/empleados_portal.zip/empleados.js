document.addEventListener("DOMContentLoaded", () => {
  const registroForm = document.getElementById("registroForm");
  const loginForm = document.getElementById("loginForm");
  const logoutBtn = document.getElementById("logoutBtn");

  if (registroForm) {
    registroForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const nombre = document.getElementById("nombre").value;
      const usuario = document.getElementById("usuarioReg").value;
      const password = document.getElementById("passwordReg").value;
      const cargo = document.getElementById("cargo").value;

      let empleados = JSON.parse(localStorage.getItem("empleados")) || [];

      if (empleados.find(emp => emp.usuario === usuario)) {
        document.getElementById("registroAlert").innerHTML = `<div class="alert alert-danger">El usuario ya existe.</div>`;
        return;
      }

      empleados.push({ nombre, usuario, password, cargo });
      localStorage.setItem("empleados", JSON.stringify(empleados));

      document.getElementById("registroAlert").innerHTML = `<div class="alert alert-success">Registro exitoso. Ahora puedes iniciar sesión.</div>`;
      registroForm.reset();
    });
  }

  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const usuario = document.getElementById("usuario").value;
      const password = document.getElementById("password").value;

      let empleados = JSON.parse(localStorage.getItem("empleados")) || [];
      const empleado = empleados.find(emp => emp.usuario === usuario && emp.password === password);

      if (empleado) {
        localStorage.setItem("empleadoActivo", JSON.stringify(empleado));
        window.location.href = "portal.html";
      } else {
        document.getElementById("loginAlert").innerHTML = `<div class="alert alert-danger">Usuario o contraseña incorrectos.</div>`;
      }
    });
  }

  if (window.location.pathname.includes("portal.html")) {
    const empleado = JSON.parse(localStorage.getItem("empleadoActivo"));
    if (!empleado) {
      window.location.href = "login.html";
    } else {
      document.getElementById("empleadoNombre").textContent = empleado.nombre;
      document.getElementById("empleadoCargo").textContent = empleado.cargo;
    }
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("empleadoActivo");
      window.location.href = "login.html";
    });
  }
});